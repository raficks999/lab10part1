const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const colors = require("colors");
const Carro = require('./models/Carro');

const app = express();
const Post = require('./models/Post');

// Configurações
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Conexão com MongoDB
mongoose.connect('mongodb://localhost:27017')
    .then(() => console.log('MongoDB conectado!'))
    .catch(err => console.log(err));

// Página inicial: Projects
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Projects.html'));
});

// Página do blog: busca todos os posts
app.get('/blog', async (req, res) => {
    try {
        const posts = await Post.find();
        res.render('blog', { posts: posts });
    } catch (err) {
        res.status(500).send('Erro ao buscar posts.');
    }
});

app.use(express.urlencoded({ extended: true }));

// Página de cadastro
app.get('/cadastrar-post', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'cadastrar_post.html'));
});

// Cadastrar post no banco
app.post('/cadastrar-post', async (req, res) => {
    try {
        const novoPost = new Post({
            titulo: req.body.titulo,
            resumo: req.body.resumo,
            conteudo: req.body.conteudo
        });

        await novoPost.save();

        // Depois de salvar, abre a confirmação
        res.redirect('/post-cadastrado');

    } catch (err) {
        console.log('Erro ao cadastrar:', err);
        res.status(500).send('Erro ao cadastrar post.');
    }
});

// Página de confirmação
app.get('/post-cadastrado', (req, res) => {
    res.render('post_cadastrado');
});

// Concessionária

app.use(express.urlencoded({ extended: true }));

app.get('/carros', async (req, res) => {
    try {
        const carros = await Carro.find();

        res.render('carros', {
            carros: carros
        });

    } catch (err) {
        res.status(500).send('Erro ao buscar carros.');
    }
});

app.get('/cadastrar-carro', (req, res) => {
    res.render('gerenciar_carro');
});

app.post('/cadastrar-carro', async (req, res) => {
    try {
        const novoCarro = new Carro({
            marca: req.body.marca,
            modelo: req.body.modelo,
            ano: req.body.ano,
            qtde_disponivel: req.body.qtde_disponivel
        });

        await novoCarro.save();

        res.redirect('/carros');

    } catch (err) {
        console.log(err);
        res.status(500).send('Erro ao cadastrar carro.');
    }
});

app.get('/atualizar-carro/:id', async (req, res) => {
    try {
        const carro = await Carro.findById(req.params.id);

        res.render('editar_carro', {
            carro: carro
        });

    } catch (err) {
        res.status(500).send('Erro ao buscar carro.');
    }
});

app.post('/atualizar-carro/:id', async (req, res) => {
    try {
        await Carro.findByIdAndUpdate(req.params.id, {
            marca: req.body.marca,
            modelo: req.body.modelo,
            ano: req.body.ano,
            qtde_disponivel: req.body.qtde_disponivel
        });

        res.redirect('/carros');

    } catch (err) {
        res.status(500).send('Erro ao atualizar carro.');
    }
});

app.post('/remover-carro/:id', async (req, res) => {
    try {
        await Carro.findByIdAndDelete(req.params.id);

        res.redirect('/carros');

    } catch (err) {
        res.status(500).send('Erro ao remover carro.');
    }
});

app.post('/vender-carro/:id', async (req, res) => {
    try {
        const carro = await Carro.findOneAndUpdate(
            {
                _id: req.params.id,
                qtde_disponivel: { $gt: 0 }
            },
            {
                $inc: { qtde_disponivel: -1 }
            },
            {
                new: true
            }
        );

        if (!carro) {
            return res.send('Esgotado!');
        }

        res.redirect('/carros');

    } catch (err) {
        res.status(500).send('Erro ao vender carro.');
    }
});

// Página de cadastro do motorista
app.get('/cadastro', (req, res) => {
    res.render('cadastro_motorista');
});

// Página de login do motorista
app.get('/login', (req, res) => {
    res.render('login_motorista');
});

// Servidor na porta 80
app.listen(80, () => {
    console.log('Servidor rodando na porta 80!'. rainbow);
});