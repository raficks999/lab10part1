
const mongoose = require('mongoose');

const CarroSchema = new mongoose.Schema({
    marca: {
        type: String,
        required: true
    },

    modelo: {
        type: String,
        required: true
    },

    ano: {
        type: Number,
        required: true
    },

    qtde_disponivel: {
        type: Number,
        required: true
    }
});

module.exports = mongoose.model('Carro', CarroSchema);
