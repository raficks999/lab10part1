const express = require('express');
const path = require('path');
const colors = require("colors");
const Carro = require('./models/Carro');

const app = express();
const Post = require('./models/Post');

// Banco de Dados

var mongodb = require("mongodb");
const MongoClient = mongodb.MongoClient;
const uri = 'mongodb://localhost:27017';
const client = new MongoClient(uri, { useNewUrlParser: true });

var dbo = client.db("blog");
var usuarios = dbo.collection("usuarios");

var mongodb = require("mongodb");

// Configurações

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Página inicial: Projects
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Projects.html'));
});

// Página do blog: busca todos os posts

let posts = dbo.collection('posts')

app.get('/blog', function (req, res) {
    let itens = [];
    res.render('blog', {itens})
});

app.get("/criar", function (req, res) {
    res.redirect('criar_post.html');
});

app.get("/cadastrar_post", function (req, res){
    let titulo = req.query.titulo;
    let resumo = req.query.resumo;
    let conteudo = req.query.conteudo;

    let data = {
        db_titulo: titulo,
        db_resumo: resumo,
        db_conteudo: conteudo
    }

    posts.insertOne(data, function (err) {
        if (err) {
            console.log(err);
            res.render('resposta_usuario', {resposta: "Erro ao cadastrar post."})
        } else {

            let data = {}
            posts.find(data).toArray(function (err, itens) {
                res.render('blog.ejs', {itens})
            })
        }
    })
}) 

// Concessionária

app.use(express.urlencoded({ extended: true }));

app.get('/carros', async (req, res) => {
    try {
        const carros = await Carro.find();

        res.render('carros', {
            carros: carros
        });

    } catch (err) {
        res.status(500).send('Erro ao buscar carros.');
    }
});

app.get('/cadastrar-carro', (req, res) => {
    res.render('gerenciar_carro');
});

app.post('/cadastrar-carro', async (req, res) => {
    try {
        const novoCarro = new Carro({
            marca: req.body.marca,
            modelo: req.body.modelo,
            ano: req.body.ano,
            qtde_disponivel: req.body.qtde_disponivel
        });

        await novoCarro.save();

        res.redirect('/carros');

    } catch (err) {
        console.log(err);
        res.status(500).send('Erro ao cadastrar carro.');
    }
});

app.get('/atualizar-carro/:id', async (req, res) => {
    try {
        const carro = await Carro.findById(req.params.id);

        res.render('editar_carro', {
            carro: carro
        });

    } catch (err) {
        res.status(500).send('Erro ao buscar carro.');
    }
});

app.post('/atualizar-carro/:id', async (req, res) => {
    try {
        await Carro.findByIdAndUpdate(req.params.id, {
            marca: req.body.marca,
            modelo: req.body.modelo,
            ano: req.body.ano,
            qtde_disponivel: req.body.qtde_disponivel
        });

        res.redirect('/carros');

    } catch (err) {
        res.status(500).send('Erro ao atualizar carro.');
    }
});

app.post('/remover-carro/:id', async (req, res) => {
    try {
        await Carro.findByIdAndDelete(req.params.id);

        res.redirect('/carros');

    } catch (err) {
        res.status(500).send('Erro ao remover carro.');
    }
});

app.post('/vender-carro/:id', async (req, res) => {
    try {
        const carro = await Carro.findOneAndUpdate(
            {
                _id: req.params.id,
                qtde_disponivel: { $gt: 0 }
            },
            {
                $inc: { qtde_disponivel: -1 }
            },
            {
                new: true
            }
        );

        if (!carro) {
            return res.send('Esgotado!');
        }

        res.redirect('/carros');

    } catch (err) {
        res.status(500).send('Erro ao vender carro.');
    }
});

// Página de cadastro do motorista
app.get('/cadastro', (req, res) => {
    res.render('cadastro_motorista');
});

// Página de login do motorista
app.get('/login', (req, res) => {
    res.render('login_motorista');
});

// Servidor na porta 80
app.listen(80, () => {
    console.log
    ('Servidor rodando na porta 80!'. rainbow);
});
