let colors = require("colors");
let http = require("http");
let express = require("express");
let bodyParser = require("body-parser")


let app = express();
app.use(express.static(__dirname + "/public"));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', './views');

let server = http.createServer(app);
server.listen(80);

console.log("Servidor rodando...". rainbow);

app.get("/cadastrar_get", (req, res) => {
    const email = req.query.email;
    const senha = req.query.senha;

    res.render("resposta.ejs", {
        email_template: email,
        senha_template: senha
    })
});

app.get("/login_get", (req, res) => {
    const email = req.query.email;
    const senha = req.query.senha;

    console.log(email, senha);
    res.render("resposta.ejs", { 
        email_template: email, 
        senha_template: senha 
    });
    
});

